https://rasa.com/docs/rasa/installation/
installation guide above

instalation
•	python3 -m venv ./venv
•	source ./venv/bin/activate
•	pip3 install rasa
•	rasa init 	# to start it\


Training
•	rasa train


run
•	rasa run actions &
•	rasa shell
•	rasa shell --debug

other good commands
•	/stop       	# to stop it
•	/restart       	# to stop it

